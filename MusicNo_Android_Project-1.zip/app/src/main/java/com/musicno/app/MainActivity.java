package com.musicno.app;

import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    LinearLayout box;
    TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(28,36,28,20);
        box.setBackgroundColor(Color.WHITE);

        TextView title = new TextView(this);
        title.setText("🎵  موزیک نو");
        title.setTextSize(30);
        title.setGravity(Gravity.RIGHT);
        box.addView(title, new LinearLayout.LayoutParams(-1,70));

        TextView sub = new TextView(this);
        sub.setText("آهنگ مورد نظرت رو پیدا کن");
        sub.setTextSize(17);
        sub.setGravity(Gravity.RIGHT);
        box.addView(sub);

        EditText search = new EditText(this);
        search.setHint("نام آهنگ یا خواننده...");
        search.setSingleLine(true);
        box.addView(search, new LinearLayout.LayoutParams(-1,65));

        Button go = new Button(this);
        go.setText("جستجوی آهنگ 🔎");
        box.addView(go, new LinearLayout.LayoutParams(-1,60));

        Button archive = new Button(this);
        archive.setText("📚 آرشیو من");
        box.addView(archive, new LinearLayout.LayoutParams(-1,60));

        status = new TextView(this);
        status.setText("آماده جستجو");
        status.setTextSize(16);
        status.setGravity(Gravity.RIGHT);
        box.addView(status, new LinearLayout.LayoutParams(-1,70));

        go.setOnClickListener(v -> {
            String q = search.getText().toString().trim();
            status.setText(q.isEmpty() ? "لطفاً نام آهنگ را وارد کن." : "جستجو برای «" + q + "» آماده است.");
        });
        archive.setOnClickListener(v -> status.setText("آرشیو موزیک نو آماده است."));
        setContentView(box);
    }
}
